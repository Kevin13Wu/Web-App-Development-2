﻿using System.Collections.Generic;

namespace web2.Models {
	public class HomeContent {
		public List<Event> Events;
		public User User;
	}
}
