﻿
namespace web2.Models {
	public class Location {
        public string Title = string.Empty;
		public string Description = string.Empty;
		public Address Address;
	}
}